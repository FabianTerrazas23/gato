package mx.edu.utch.gto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
